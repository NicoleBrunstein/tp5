const config ={
    host: "localhost",
    database:"dai-events",
    user:"postgres",
    password:"1234",
    port:5432

}
export default config;