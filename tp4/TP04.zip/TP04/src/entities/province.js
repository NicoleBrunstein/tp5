class Province{
    id;
    name;
    full_name;
    latitude;
    longitude;
    display_order;
}
export default Province;